# Book-and-Character-System
This is a java console based application that allows a user to add, delete , sort search and update book and characters using hashmaps and linkedlists in data structures
