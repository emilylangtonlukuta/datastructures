import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class foodDrink {
	public String nameOfFoodOrBeverage;
	public double price;
	//double in oder for the price to be written in format 3.00 / 21.00
	public  int itemId;
	foodDrink next = null;


	public foodDrink(String nameOfFoodOrBeverage, double price, int itemId) {
		this.nameOfFoodOrBeverage = nameOfFoodOrBeverage;
		this.price = price;
		this.itemId = itemId;
		
	}

	public String getNameOfFoodOrBeverage() {
		return nameOfFoodOrBeverage;
	}

	public void setNameOfFoodOrBeverage(String nameOfFoodOrBeverage) {
		nameOfFoodOrBeverage = nameOfFoodOrBeverage;
	}

	public  double getPrice() {
		return price;
	}

	public  void setPrice(double price) {
		price = price;
	}

	public  int getItemId() {
		return itemId;
	}

	public static void setItemId(int itemId) {
		itemId = itemId;
	}
	
}
