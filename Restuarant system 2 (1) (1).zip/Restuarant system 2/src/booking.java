import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class booking {
	public  String bookingName;
	public  int noOfPeople;
	public  double timeForBooking;
	public  double hours;
	public  int bookingId;
	booking next = null;
	//attributes
	
public booking( String bookingName,int noOfPeople,double timeForBooking, double hours,int bookingId) {
	
	this.bookingName = bookingName;
	this.noOfPeople = noOfPeople;
	this.timeForBooking = timeForBooking;
	this.hours = hours;
	this.bookingId = bookingId;
}
//constructor

//getters and setters
public String getBookingName() {
	return bookingName;
}

public void setBookingName(String bookingName) {
	this.bookingName = bookingName;
}

public int getNoOfPeople() {
	return noOfPeople;
}

public void setNoOfPeople(int noOfPeople) {
	this.noOfPeople = noOfPeople;
}

public double getTimeForBooking() {
	return timeForBooking;
}

public void setTimeForBooking(double timeForBooking) {
	this.timeForBooking = timeForBooking;
}

public double getHours() {
	return hours;
}

public void setHours(double hours) {
	this.hours = hours;
}

public int getBookingId() {
	return bookingId;
}

public void setBookingId(int bookingId) {
	this.bookingId = bookingId;
}

}
