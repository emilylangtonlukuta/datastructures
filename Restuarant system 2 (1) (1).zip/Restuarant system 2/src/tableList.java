
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;



// TODO: Auto-generated Javadoc

public class tableList {

	private static int counter = 0;
	private static table head = null;
	

	
	public  tableList() {
	}

	
	public static void setHead(table head) {
		head = head;
	}
	
	
	public table getHead()
	{
		return head;
	}

	/**
	 * Adds a table.
	 *
	 * @param table the table
	 */
	public static void addTable(table Table) {
		if (head == null) {
			head = Table;	// initiate by adding the first table
		} else {
			Table.next = head;	
			head = Table;	// adds the next table as a head node
		}
		counter++;	//increment the counter
	}

	/**
	 * Delete a table.
	 *
	 * @param table the table
	 */
	public  static void deleteTable(table Table) {
		if (head == null) {
			System.out.println("There are no tables at the restaurant");	//if the first node is empty (null).
			
		} else if (head.equals(Table)) {
			head = head.next;
			System.out.println("Table deleted successfully");	// if it points to the next node, meaning that the current node is deleted.
		} else {
			table current = head;
			// iterate through the linked list
			while (current.next != null) {
				
				if (current == Table) {
					table previous = findPrevious(Table);
					previous.next = current.next;
					System.out.println("Table deleted successfully");
				}
				
				current = current.next;
			}
			if (current.next == null && current == Table) {
				table previous = findPrevious(Table);
				System.out.println("Table deleted successfully"); 	//if the head of the current node is now the the head of previous node before deleting.
				previous.next = null;
			}
		}
		driver.standbyStartMenu();
	}

	/**
	 * Find.
	 *
	 * @param table the table
	 * @return the table
	 */
	public table find(table Table) {

		if (head == null)
			return null;

		if (head == Table)
			return head;

		table current = head;

		while (current.next != null) {
			current = current.next;
			if (current == Table)
				return current;
		}
		return null;
	}

	/**
	 * Find previous table.
	 *
	 * @param table the table
	 * @return the table
	 */
	public static table findPrevious(table Table) {

		if (head == Table)
			return null;
		// Check the first element for match

		table current = head;
		table previous = null;
		
	
		// iterate through the linked list
		while (current.next != null) {
			previous = current;
			current = current.next;
			if (current == Table)
				return previous;
		}
		return null;
	}

	/**
	 * Find the previous table node in the list
	 *
	 * @param tableNumber the table number
	 * @return the table
	 */
	public static table findTableId(int tableId) {

		if (head == null)
			return null;

		if (head.tableId == tableId)
			return head;

		table current = head;

		while (current.next != null) {
			current = current.next;
			if (current.tableId == tableId)
				return current;
		}
		return null;

	}

	/**
	 * List tables.
	 *
	 * @return the string
	 */
	public static void  viewTables() {
		if (head == null) {
			System.out.println("There are no tables in the restaurant");
		} else {
			table current = head;
			while (current != null) {
				System.out.println("table id:  " + current.getTableId() + "  Seats:  " + current.getSeats());

				current = current.next; 
			}
			driver.standbyStartMenu();
		}
	}

}

