/**
 * @author  Emily Lukuta 20079889
 * 
 */
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class table{
	
	public int tableId;// this is for the table id
	public int seats;// this is an attribute for the number of seats 
	table next = null;
/**
 * attributes
 * @param tableId
 * @param seats
 */
	public table(int tableId, int seats) {
		this.tableId = tableId;
		this.seats = seats;
	}
/**
 * this is the constructor for my table class 
 * @return
 */
	public int getTableId() {
		return tableId;
	}

	public void setTableId(int tableId) {
		this.tableId = tableId;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

}
