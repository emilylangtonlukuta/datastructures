import java.util.Scanner;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class driver {
	
	
	
	
	static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args){
		
		viewMenu();
	}
	
	
	public static void viewMenu() {
		System.out.println("******WELCOME TO RESTUARANT SYSTEM MENU******");
		System.out.println("-----------Choose an option------------");
		System.out.println("         1) Tables ");
		System.out.println("         2) Bookings ");
		System.out.println("         3) Food and Beverages ");
		System.out.println("         4) CheckIn ");
		System.out.println("         5) CheckOut ");
		System.out.println("         6) Reset ");
		System.out.print("              Enter your option: ");
		//prints out the "***" into the console
		int option = input.nextInt();
		// takes in integer values from the keyboard  
		
		
		switch (option) {
		case 1: tablesMenu();
				break;
		case 2: bookingsMenu();
				break;
		case 3: foodBeverageMenu();
				break;
		 case 4: checkIn();
			break;
	    case 5: checkOut();
			break;
	    case 6: reset();
		break;
		
		//Static way of calling methods from another class 
		//provides three options for the integer inputs keyed in by the user 
		}}
/**
 * This is the standby method very similar to the startMenu ....this is excecuted after a user has selected their options
 * to allow them to pick another option
 */
		public static void standbyStartMenu() {
			System.out.println("****** RESTUARANT SYSTEM MENU******");
			System.out.println("-----------Choose another option------------");
			System.out.println("         1) Tables ");
			System.out.println("         2) Bookings ");
			System.out.println("         3) Food and Beverages ");
			System.out.println("         4) CheckIn ");
			System.out.println("         5) CheckOut ");
			System.out.println("         5) Reset ");
			System.out.print("              Enter your option: ");
			
			
			int option = input.nextInt();
			

			switch (option) {
			case 1: tablesMenu();
					break;
			case 2: bookingsMenu();
					break;
			case 3: foodBeverageMenu();
					break;
			 case 4: checkIn();
				break;
		    case 5: checkOut();
				break;
		    case 6: reset();
			break;
			}
		
		}
		public static void foodBeverageMenu() {
			System.out.println("*********WELCOME TO RESTUARANT Food and Beverage MENU*********");
			System.out.println("-----------Choose an option------------");
			System.out.println("         1) Add a new Food/Drink ");
			System.out.println("         2) View all Foods/Drinks     ");
			System.out.println("         3) Delete all menu items ");
			System.out.println("       4) Search for f/d item");
			System.out.print("              Enter your option: ");
			int option = input.nextInt();
			
			
			
			switch (option) {
			case 1: addFoodDrinkItem();
					break;
			case 2: foodDrinkList.viewFoodDrink();
					break;
			case 3: deleteTheFoodDrink();
					break;
			}
}
		public static  void tablesMenu() {
			System.out.println("***************WELCOME TO RESTUARANT TABLES MENU******************");
			System.out.println("-----------Choose an option------------");
			System.out.println("         1) Add a new Table ");
			System.out.println("         2) View all Tables     ");
			System.out.println("         3) Delete a Table ");
			System.out.println("       4) Search for a Table ");
			System.out.println("              Enter your option: ");
			int option = input.nextInt();
			
			
			
			switch (option) {
			case 1: addTheTable();
					break;
			case 2: tableList.viewTables();
					break;
			case 3: deleteTheTable();
					break;
			//case 4: searchNewTable();
					//break;
			}
		}
		public static  void bookingsMenu() {
			System.out.println("*********WELCOME TO RESTUARANT Bookings MENU*********");
			System.out.println("-----------Choose an option------------");
			System.out.println("         1) Add a new Booking ");
			System.out.println("         2) View all Bookings     ");
			System.out.println("         3) Delete a Booking ");
			
			System.out.print("              Enter your option: ");
			int option = input.nextInt();
			
			
			
		switch (option) {
			case 1: addTheBooking();
					break;
			case 2: bookingList.viewBookings();
					break;
			case 3:deleteTheBooking();
				break;
		   
			}
		}
		
		public static void addFoodDrinkItem() {
			System.out.println("Please enter name food or Drink :"); 
			input.nextLine();
			//takes in characters from the keyboard 
			String nameOfFoodOrBeverage = input.nextLine();
			System.out.println("item Id :");
			int itemId =input.nextInt();
			System.out.println("Please enter the price of the Instigated Item:");
			double price = input.nextDouble();
			//takes in data from the keyboard in form 6.00
			System.out.println("item :" + nameOfFoodOrBeverage + "Price: E"+ price + "added"); 
			foodDrinkList.addfoodDrink(new  foodDrink( nameOfFoodOrBeverage, price, itemId));
			
			standbyStartMenu();
		}
	public static void addTheBooking() {
		System.out.println("Please enter name for booking:"); 
		input.nextLine();
		String bookingName = input.nextLine();
		System.out.println("Number of people booking is for:");
		int noOfPeople = input.nextInt();
		System.out.println("Table ID being booked:");
		int bookingId = input.nextInt();
		System.out.println("Booking time in form 8.00,21.00 etc..:");
		double timeForBooking = input.nextDouble();
		System.out.println("Duration of booking in form 5.00 etc..:");
		double hours = input.nextDouble();
		System.out.println("booking Name:" + bookingName);
		System.out.println(" No. of people :"+ noOfPeople );
		System.out.println(" Table ID :"+ bookingId );
		System.out.println(" Booking time:"+ timeForBooking );
		System.out.println(" Duration :"+ hours );
		bookingList.addBooking(new booking(  bookingName, noOfPeople, timeForBooking, hours, bookingId));
		standbyStartMenu();
		}
	
	public static  void addTheTable() {
		System.out.println("Enter the no. seats would you like: ");
		int seats = input.nextInt();
		// takes in intergers from keyboard
		System.out.println("table of "+ seats + "  created");
		System.out.println("Your table id in numbers: ");
		int tableId = input.nextInt();
		System.out.println(" table of :"+ seats +" Table id: "+ tableId + "created.");
		tableList.addTable(new table( tableId,  seats));
		standbyStartMenu();
}
	public static void deleteTheTable() {
		;
		System.out.print("Please enter table Id to delete : ");
		int tableId = input.nextInt();
		table tableDelete = tableList.findTableId(tableId);
		tableList.deleteTable(tableDelete);
		standbyStartMenu();
	}

	
	public static void deleteTheBooking() {
		
		System.out.print("Please enter booking Id to delete:");
		int bookingId = input.nextInt();
		booking bookingDelete = bookingList.findBookingId(bookingId);
		bookingList.deleteBooking(bookingDelete);
		standbyStartMenu();
	}
	
	
	public static void deleteTheFoodDrink() {
		
		System.out.print("Please enter the item Id to delete: ");
		int itemId = input.nextInt();
		foodDrink itemDelete = foodDrinkList.findItemId(itemId);
		foodDrinkList.deleteFoodDrink(itemDelete);
		standbyStartMenu();
	
}
	public static void checkIn() {
		System.out.print("Please enter booking ID: ");
		int bookingId = input.nextInt();
		booking toCheckIn = bookingList.findBookingId(bookingId);
		checkIn();
		standbyStartMenu();
	}

	/**
	 * Check out booking.
	 */
	
	public static void checkOut() {
		System.out.print("Please enter booking ID: ");
		int bookingId = input.nextInt();
		booking toCheckOut = bookingList.findBookingId(bookingId);
		checkIn();
		standbyStartMenu();
	}


	
	public static void reset() {
		System.out.println("RESET SUCCESSFUL");
		tableList.setHead(null);
		bookingList.setHead(null);
		foodDrinkList.setHead(null);
		standbyStartMenu();
		
	}
	//public void load() throws Exception
   // {
       //XStream xstream = new XStream(new DomDriver());
        //ObjectInputStream is = xstream.createObjectInputStream(new FileReader("save.xml"));
        //tbl = tbl;  is.readObject();
       // bookingList = bookingList;  is.readObject();
       // foodDrinkList = foodDrinkList; is.readObject();
        //is.close();
   // }
    
  
	//public void save() throws Exception
    //{
       // XStream xstream = new XStream(new DomDriver());
       // ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("save.xml"));
      //  out.writeObject(tableList);
        //out.writeObject(bookingList);
      //  out.writeObject(foodDrinkList);
       //out.close();    
  //  }
	}
	

