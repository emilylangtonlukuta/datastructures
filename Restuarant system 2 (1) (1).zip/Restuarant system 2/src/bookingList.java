import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;



	public class bookingList {

		private static int counter = 0;
		private static booking head = null;
		

		
		public bookingList() {
		}

		
		public static void setHead(booking head) {
			head = head;
		}
		
		
		public booking getHead()
		{
			return head;
		}

		/**
		 * Adds a table.
		 *
		 * @param table the table
		 */
		public static void addBooking(booking Booking) {
			if (head == null) {
				head = Booking;	// initiate by adding the first table
			} else {
				Booking.next = head;	
				head = Booking;	// adds the next table as a head node
			}
			counter++;	//increment the counter
		}

		/**
		 * Delete a table.
		 *
		 * @param table the table
		 */
		public static void deleteBooking(booking Booking) {
			if (head == null) {
				System.out.println("There are no bookings at the restaurant");	//if the first node is empty (null).
				
			} else if (head.equals(Booking)) {
				head = head.next;
				System.out.println("Booking deleted successfully");	// if it points to the next node, meaning that the current node is deleted.
			} else {
				booking current = head;
				// iterate through the linked list
				while (current.next != null) {
					
					if (current == Booking) {
						booking previous = findPrevious(Booking);
						previous.next = current.next;
						System.out.println("Booking deleted successfully");
					}
					
					current = current.next;
				}
				if (current.next == null && current == Booking) {
					booking previous = findPrevious(Booking);
					System.out.println("Booking deleted successfully"); 	//if the head of the current node is now the the head of previous node before deleting.
					previous.next = null;
				}
			}
			driver.standbyStartMenu();
		}

		/**
		 * Find.
		 *
		 * @param table the table
		 * @return the table
		 */
		public booking find(booking Booking) {

			if (head == null)
				return null;

			if (head == Booking)
				return head;

			booking current = head;

			while (current.next != null) {
				current = current.next;
				if (current == Booking)
					return current;
			}
			return null;
		}

		/**
		 * Find previous table.
		 *
		 * @param table the table
		 * @return the table
		 */
		public static booking findPrevious(booking Booking) {

			if (head == Booking)
				return null;
			// Check the first element for match

			booking current = head;
			booking previous = null;
			
		
			// iterate through the linked list
			while (current.next != null) {
				previous = current;
				current = current.next;
				if (current == Booking)
					return previous;
			}
			return null;
		}

		/**
		 * Find the previous table node in the list
		 *
		 * @param tableNumber the table number
		 * @return the table
		 */
		public static booking findBookingId(int bookingId) {

			if (head == null)
				return null;

			if (head.bookingId == bookingId)
				return head;

			booking current = head;

			while (current.next != null) {
				current = current.next;
				if (current.bookingId == bookingId)
					return current;
			}
			return null;

		}

		/**
		 * List tables.
		 *
		 * @return the string
		 */
		public static void viewBookings() {
			if (head == null) {
				System.out.println("There are no bookings in the restaurant");
			} else {
				booking current = head;
				while (current != null) {
					System.out.println("Booking Name:  " + current.getBookingName()+  "BookingId:  "+ current.getBookingId() + "Time:  "+  current.getTimeForBooking() +"No. of People:  " + current.getNoOfPeople() + "Amount of Hours:  "+current.getHours());

					current = current.next;
				}
				driver.standbyStartMenu();
			}
		}

	}


