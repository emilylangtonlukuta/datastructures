import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class foodDrinkList {
	

	private static int counter = 0;
	private static foodDrink head = null;
	
	
	static Scanner input = new Scanner(System.in);
	
	public  foodDrinkList() {
	}

	
	public static void setHead( foodDrink head) {
		head = head;
	}
	
	
	public  foodDrink getHead()
	{
		return head;
	}

	/**
	 * Adds a table.
	 *
	 * @param table the table
	 */
	public static  void addfoodDrink( foodDrink  FoodDrink) {
		if (head == null) {
			head =  FoodDrink;	// initiate by adding the first table
		} else {
			FoodDrink.next = head;	
			head =  FoodDrink;	// adds the next table as a head node
		}
		counter++;	//increment the counter
	}

	/**
	 * Delete a table.
	 *
	 * @param table the table
	 */
	public static  void deleteFoodDrink( foodDrink  FoodDrink) {
		if (head == null) {
			System.out.println("There are no items at the Food Menu");	//if the first node is empty (null).
			
		} else if (head.equals( FoodDrink)) { 
			head = head.next;
			System.out.println("Item deleted successfully");	// if it points to the next node, meaning that the current node is deleted.
		} else {
			 foodDrink current = head;
			// iterate through the linked list
			while (current.next != null) {
				
				if (current ==  FoodDrink) {
					 foodDrink previous = findPrevious( FoodDrink);
					previous.next = current.next;
					System.out.println("Items  deleted successfully");
				}
				
				current = current.next;
			}
			if (current.next == null && current ==  FoodDrink) {
				 foodDrink previous = findPrevious( FoodDrink);
				System.out.println(" deleted successfully"); 	//if the head of the current node is now the the head of previous node before deleting.
				previous.next = null;
			}
		}
		driver.standbyStartMenu();
	}

	/**
	 * Find.
	 *
	 * @param table the table
	 * @return the table
	 */
	public  foodDrink find( foodDrink FoodDrink) {

		if (head == null)
			return null;

		if (head ==  FoodDrink)
			return head;

		 foodDrink current = head;

		while (current.next != null) {
			current = current.next;
			if (current ==  FoodDrink)
				return current;
		}
		return null;
	}

	/**
	 * Find previous table.
	 *
	 * @param table the table
	 * @return the table
	 */
	public static  foodDrink findPrevious( foodDrink FoodDrink) {

		if (head ==  FoodDrink)
			return null;
		// Check the first element for match

		 foodDrink current = head;
		 foodDrink previous = null;
		
	
		// iterate through the linked list
		while (current.next != null) {
			previous = current;
			current = current.next;
			if (current ==  FoodDrink)
				return previous;
		}
		return null;
	}

	/**
	 * Find the previous table node in the list
	 *
	 * @param tableNumber the table number
	 * @return the table
	 */
	public static foodDrink findItemId(int itemId) {

		if (head == null)
			return null;

		if (head.itemId == itemId)
			return head;

		 foodDrink current = head;

		while (current.next != null) {
			current = current.next;
			if (current. itemId == itemId)
				return current;
		}
		return null;

	}

	/**
	 * List tables.
	 *
	 * @return the string
	 */
	public static void viewFoodDrink() {
		if (head == null) {
			System.out.println("There is no food in the menu");
		} else {
			 foodDrink current = head;
			while (current != null) {
				System.out.println("item id: " + current.getItemId() + "   item name: " + current.getNameOfFoodOrBeverage() + "   item price: E"+ current.getPrice());

				current = current.next;
			}
		
		}
		driver.standbyStartMenu();
	}
	

}



